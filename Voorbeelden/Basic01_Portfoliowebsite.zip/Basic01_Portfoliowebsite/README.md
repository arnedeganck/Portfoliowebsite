# Portfolio Website

This is a simple portfolio website created using HTML, CSS, and JavaScript.

## Structure

- `index.html`: Homepage with an introduction.
- `about.html`: About me page.
- `projects.html`: Projects page to showcase your work.
- `contact.html`: Contact form to allow visitors to get in touch.
- `css/`: Contains the main styles for the website.
- `js/`: Contains JavaScript files for interaction and form validation.
- `assets/`: Contains images, icons, and other media files used on the website.

## Technologies Used

- HTML
- CSS
- JavaScript

## How to run

1. Clone or download the repository.
2. Open `index.html` in your browser.
