// Placeholder voor formulier validatie (indien nodig voor het contactformulier)
document.querySelector("form").addEventListener("submit", function(event) {
    if (!event.target.checkValidity()) {
        event.preventDefault();
        alert("Please fill out all fields.");
    }
});
