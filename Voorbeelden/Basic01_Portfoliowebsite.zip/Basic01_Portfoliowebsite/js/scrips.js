// Placeholder voor eventuele JavaScript-functionaliteit, zoals interactieve elementen
console.log("Welcome to the Portfolio!");
