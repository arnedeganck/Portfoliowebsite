// JavaScript functionality can be added here, like form handling or animations
console.log("JavaScript file loaded successfully.");

// Example: Show an alert when button is clicked
function showAlert() {
    alert("Thank you for your interest!");
}
