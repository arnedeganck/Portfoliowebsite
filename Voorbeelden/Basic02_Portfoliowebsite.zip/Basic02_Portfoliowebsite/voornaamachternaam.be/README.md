1. Mappenstructuur uitdenken en aanmaken: Hieronder krijgen jullie een mogelijk overzicht.
    /project-portfolio
    │
    ├── /assets                # Alle statische bestanden zoals afbeeldingen, video's en documenten
    │   ├── /images            # Afbeeldingen
    │   ├── /videos            # Video's
    │   ├── /docs              # Documenten (bijv. PDF's, CV, certificaten)
    │
    ├── /css                   # Alle CSS-bestanden voor de opmaak
    │   ├── styles.css         # Hoofd-CSS-bestand voor de website
    │
    ├── /js                    # JavaScript-bestanden voor interactieve functionaliteiten
    │   ├── scripts.js         # Hoofd-JavaScript-bestand
    │
    ├── /projects              # Subpagina's voor elk project
    │   ├── project1.html      # HTML-bestand voor het eerste project
    │   ├── project2.html      # HTML-bestand voor het tweede project
    │
    ├── index.html             # Homepage van het portfolio
    ├── about.html             # Over mij-pagina
    ├── contact.html           # Contactpagina
    └── README.md              # Optioneel: Document met uitleg over de structuur en werking van de website

2. Website opbouw: